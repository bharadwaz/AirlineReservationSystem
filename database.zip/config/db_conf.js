module.exports = {
   "host": 'localhost',
   "user": 'root',
   "password":'mysql@123',
   'database': 'airline_reservation'   
}
module.exports = {
 "level": "info",
 "file":"../logs/log.text"
}